document.addEventListener('DOMContentLoaded', function () {
    const multiselects = document.querySelectorAll('.multiselect');
    const nextButton = document.getElementById('submit-button');
    const popup = document.getElementById('overlay'); // Assuming the popup div has this ID
    const closePopupButton = document.getElementById('closePopup'); // Assuming the "Got it" button has this ID

    let currentOpenDropdown = null;

    multiselects.forEach(multiselect => {
        const input = multiselect.querySelector('.select-field');
        const dropdown = multiselect.querySelector('.dropdown-content');
        const checkboxes = dropdown.querySelectorAll('input[type="checkbox"]');
        const dropdownIcon = multiselect.querySelector('.dropdown-icon');

        input.addEventListener('click', function (event) {
            event.stopPropagation(); // Prevent the click from bubbling up to the document
            if (currentOpenDropdown && currentOpenDropdown !== dropdown) {
                currentOpenDropdown.classList.remove('show');
            }
            dropdown.classList.toggle('show');
            currentOpenDropdown = dropdown.classList.contains('show') ? dropdown : null;
        });

        dropdownIcon.addEventListener('click', function (event) {
            event.stopPropagation(); // Prevent the click from bubbling up to the document
            if (currentOpenDropdown && currentOpenDropdown !== dropdown) {
                currentOpenDropdown.classList.remove('show');
            }
            dropdown.classList.toggle('show');
            currentOpenDropdown = dropdown.classList.contains('show') ? dropdown : null;
        });

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function () {
                updateInputValue(input, dropdown);
            });
        });

        dropdown.addEventListener('click', function (event) {
            event.stopPropagation(); // Prevent the click from bubbling up to the document
        });
    });

    function updateInputValue(input, dropdown) {
        const checkedBoxes = dropdown.querySelectorAll('input[type="checkbox"]:checked');
        const selectedValues = Array.from(checkedBoxes).map(checkbox => checkbox.value);
        input.value = selectedValues.join(', ');

        checkAllFilled();
    }

    // function checkAllFilled() {
    //     const inputs = document.querySelectorAll('.select-field');
    //     let allFilled = true;

    //     inputs.forEach(input => {
    //         if (!input.value) {
    //             allFilled = false;
    //         }
    //     });

    //     const submitButton = document.getElementById('submit-button');
    //     if (allFilled) {
    //         submitButton.disabled = false;
    //         submitButton.style.opacity = '1';
    //         submitButton.style.cursor = 'pointer';
    //     } else {
    //         submitButton.disabled = true;
    //         submitButton.style.opacity = '0.5';
    //         submitButton.style.cursor = 'not-allowed';
    //     }
    // }

    nextButton.addEventListener('click', async function (e) {
        e.preventDefault(); // Prevent default form submission

        const allInputs = document.querySelectorAll('.select-field');
        let allFieldsFilled = true;

        allInputs.forEach(input => {
            if (!input.value) {
                allFieldsFilled = false;
            }
        });

        if (!allFieldsFilled) {
            popup.style.display = 'flex';
            return; // Exit the function early if not all fields are filled
        }

        const data = {};

        multiselects.forEach(multiselect => {
            const category = multiselect.querySelector('.select-field').id;
            const checkboxes = multiselect.querySelectorAll('.checkbox input[type="checkbox"]');
            const selectedValues = Array.from(checkboxes)
                .filter(checkbox => checkbox.checked)
                .map(checkbox => checkbox.value);

            data[category] = selectedValues;
        });
        data["email"] = localStorage.getItem("userEmail");

        try {
            const response = await fetch('https://regnum-backend-bice.vercel.app/update-details', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data),
            });

            if (response.ok) {
                alert("submitted!");
                window.location.href = '../photo/index.html';
            } else {
                const errorData = await response.json();
                console.error('Error updating user information:', errorData);
            }
        } catch (error) {
            console.error('Error updating user information:', error);
        }
    });

    function closeAllDropdowns() {
        const dropdowns = document.querySelectorAll('.dropdown-content.show');
        dropdowns.forEach(dropdown => {
            dropdown.classList.remove('show');
        });
        currentOpenDropdown = null;
    }

    // Close dropdowns when clicking outside
    document.addEventListener('click', function (event) {
        closeAllDropdowns();
    });

    // Close popup when "Got it" button is clicked
    closePopupButton.addEventListener('click', function () {
        popup.style.display = 'none';
    });
});


document.querySelector('.close-popup-button').addEventListener('click', function () {
    document.querySelector('.overlay').style.display = 'none';
    document.querySelector('.background-overlay').style.display = 'none';
  });
   
  var cnt =0;
  document.querySelector('.button-container button').addEventListener('click', function () {
    if(cnt==0){
    document.querySelector('.overlay').style.display = 'flex';
    document.querySelector('.background-overlay').style.display = 'block';
    cnt++;
    }
  });
  
  